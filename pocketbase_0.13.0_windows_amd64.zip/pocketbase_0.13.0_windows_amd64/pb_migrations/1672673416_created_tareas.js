migrate((db) => {
  const collection = new Collection({
    "id": "vnqo14u55d0vubr",
    "created": "2023-01-02 15:30:16.873Z",
    "updated": "2023-01-02 15:30:16.873Z",
    "name": "tareas",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "urs0troc",
        "name": "nombre",
        "type": "text",
        "required": true,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "qgwkxtoz",
        "name": "descripcion",
        "type": "text",
        "required": true,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "hemn59hs",
        "name": "fecha_init",
        "type": "date",
        "required": false,
        "unique": false,
        "options": {
          "min": "",
          "max": ""
        }
      },
      {
        "system": false,
        "id": "g0nijthg",
        "name": "fecha_fin",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "kldfk4m4",
        "name": "estatus",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "42ldrijw",
        "name": "departamento",
        "type": "relation",
        "required": true,
        "unique": false,
        "options": {
          "maxSelect": 1,
          "collectionId": "t6ml647y4no116f",
          "cascadeDelete": false
        }
      },
      {
        "system": false,
        "id": "g5s0zp6h",
        "name": "usuario",
        "type": "relation",
        "required": true,
        "unique": false,
        "options": {
          "maxSelect": 1,
          "collectionId": "_pb_users_auth_",
          "cascadeDelete": false
        }
      },
      {
        "system": false,
        "id": "mcmilhkp",
        "name": "archivos",
        "type": "bool",
        "required": false,
        "unique": false,
        "options": {}
      }
    ],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("vnqo14u55d0vubr");

  return dao.deleteCollection(collection);
})
