migrate((db) => {
  const collection = new Collection({
    "id": "jc7j3t7vyhz2pco",
    "created": "2023-03-06 00:25:40.905Z",
    "updated": "2023-03-06 00:25:40.905Z",
    "name": "tipo_lista",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "ozusrkkv",
        "name": "name",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      }
    ],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("jc7j3t7vyhz2pco");

  return dao.deleteCollection(collection);
})
