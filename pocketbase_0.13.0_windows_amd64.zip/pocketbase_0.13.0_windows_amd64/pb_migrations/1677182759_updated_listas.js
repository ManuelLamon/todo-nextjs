migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("w5pjj2kr98teal2")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "3efgigha",
    "name": "usuario_last_update",
    "type": "relation",
    "required": true,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "collectionId": "_pb_users_auth_",
      "cascadeDelete": false
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("w5pjj2kr98teal2")

  // remove
  collection.schema.removeField("3efgigha")

  return dao.saveCollection(collection)
})
