migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("w5pjj2kr98teal2")

  // remove
  collection.schema.removeField("17j3jajf")

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("w5pjj2kr98teal2")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "17j3jajf",
    "name": "tarea",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "maxSelect": null,
      "collectionId": "vnqo14u55d0vubr",
      "cascadeDelete": false
    }
  }))

  return dao.saveCollection(collection)
})
