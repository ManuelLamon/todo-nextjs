migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("vnqo14u55d0vubr")

  // remove
  collection.schema.removeField("kldfk4m4")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "edjlrpvo",
    "name": "index",
    "type": "number",
    "required": true,
    "unique": false,
    "options": {
      "min": null,
      "max": null
    }
  }))

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "akmfkryx",
    "name": "lista",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "collectionId": "w5pjj2kr98teal2",
      "cascadeDelete": false
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("vnqo14u55d0vubr")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "kldfk4m4",
    "name": "estatus",
    "type": "text",
    "required": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  // remove
  collection.schema.removeField("edjlrpvo")

  // remove
  collection.schema.removeField("akmfkryx")

  return dao.saveCollection(collection)
})
