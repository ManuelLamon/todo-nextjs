migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("vnqo14u55d0vubr")

  // remove
  collection.schema.removeField("edjlrpvo")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "8hpn2gbi",
    "name": "index",
    "type": "text",
    "required": true,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("vnqo14u55d0vubr")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "edjlrpvo",
    "name": "index",
    "type": "number",
    "required": true,
    "unique": false,
    "options": {
      "min": 0,
      "max": null
    }
  }))

  // remove
  collection.schema.removeField("8hpn2gbi")

  return dao.saveCollection(collection)
})
