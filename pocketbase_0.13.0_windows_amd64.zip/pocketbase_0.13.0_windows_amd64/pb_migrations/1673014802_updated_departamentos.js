migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("t6ml647y4no116f")

  collection.listRule = ""

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("t6ml647y4no116f")

  collection.listRule = null

  return dao.saveCollection(collection)
})
