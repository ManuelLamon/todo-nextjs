migrate((db) => {
  const collection = new Collection({
    "id": "bz1yy1pm46sc9p1",
    "created": "2023-01-02 15:30:16.873Z",
    "updated": "2023-01-02 15:30:16.873Z",
    "name": "estatus_proyectos",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "5q88q0ay",
        "name": "nombre",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "3nvrv0xj",
        "name": "departamento",
        "type": "relation",
        "required": false,
        "unique": false,
        "options": {
          "maxSelect": 10,
          "collectionId": "t6ml647y4no116f",
          "cascadeDelete": true
        }
      }
    ],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("bz1yy1pm46sc9p1");

  return dao.deleteCollection(collection);
})
