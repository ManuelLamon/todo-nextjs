migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("bz1yy1pm46sc9p1")

  // remove
  collection.schema.removeField("3nvrv0xj")

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("bz1yy1pm46sc9p1")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "3nvrv0xj",
    "name": "departamento",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "maxSelect": 10,
      "collectionId": "t6ml647y4no116f",
      "cascadeDelete": true
    }
  }))

  return dao.saveCollection(collection)
})
