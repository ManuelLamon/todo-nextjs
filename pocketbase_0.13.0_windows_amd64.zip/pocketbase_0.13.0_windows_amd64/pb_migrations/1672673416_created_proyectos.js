migrate((db) => {
  const collection = new Collection({
    "id": "ltpjrnlanenabg2",
    "created": "2023-01-02 15:30:16.873Z",
    "updated": "2023-01-02 15:30:16.873Z",
    "name": "proyectos",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "2vjdm3ve",
        "name": "nombre",
        "type": "text",
        "required": true,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "sdt1eljr",
        "name": "estatus",
        "type": "text",
        "required": true,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      }
    ],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("ltpjrnlanenabg2");

  return dao.deleteCollection(collection);
})
