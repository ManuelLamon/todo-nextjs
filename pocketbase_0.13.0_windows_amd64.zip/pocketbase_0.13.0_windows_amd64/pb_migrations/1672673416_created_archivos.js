migrate((db) => {
  const collection = new Collection({
    "id": "zfny7t9q5gb37yj",
    "created": "2023-01-02 15:30:16.873Z",
    "updated": "2023-01-02 15:30:16.873Z",
    "name": "archivos",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "4lwtr35f",
        "name": "nombre",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "avulyziv",
        "name": "url",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "ph4hcjer",
        "name": "tipo",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "gsewrpxe",
        "name": "tarea",
        "type": "relation",
        "required": false,
        "unique": false,
        "options": {
          "maxSelect": 1,
          "collectionId": "vnqo14u55d0vubr",
          "cascadeDelete": true
        }
      },
      {
        "system": false,
        "id": "vxgd1ill",
        "name": "archivo",
        "type": "file",
        "required": true,
        "unique": false,
        "options": {
          "maxSelect": 1,
          "maxSize": 5242880,
          "mimeTypes": [
            "application/zip",
            "application/x-7z-compressed",
            "application/x-rar-compressed/application/pdf",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
          ],
          "thumbs": []
        }
      }
    ],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("zfny7t9q5gb37yj");

  return dao.deleteCollection(collection);
})
