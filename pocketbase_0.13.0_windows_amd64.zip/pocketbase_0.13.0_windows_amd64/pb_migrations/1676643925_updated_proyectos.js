migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("ltpjrnlanenabg2")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "aqtjj4m6",
    "name": "image",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "collectionId": "zfny7t9q5gb37yj",
      "cascadeDelete": false
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("ltpjrnlanenabg2")

  // remove
  collection.schema.removeField("aqtjj4m6")

  return dao.saveCollection(collection)
})
