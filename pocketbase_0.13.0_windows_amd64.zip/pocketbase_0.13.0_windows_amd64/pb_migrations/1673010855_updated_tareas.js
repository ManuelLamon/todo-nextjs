migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("vnqo14u55d0vubr")

  // remove
  collection.schema.removeField("mcmilhkp")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "bo3yeptu",
    "name": "archivos",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "collectionId": "zfny7t9q5gb37yj",
      "cascadeDelete": false
    }
  }))

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "qr1cd2uy",
    "name": "usuario_responsable",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "collectionId": "_pb_users_auth_",
      "cascadeDelete": false
    }
  }))

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "g5s0zp6h",
    "name": "usuario_creador",
    "type": "relation",
    "required": true,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "collectionId": "_pb_users_auth_",
      "cascadeDelete": false
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("vnqo14u55d0vubr")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "mcmilhkp",
    "name": "archivos",
    "type": "bool",
    "required": false,
    "unique": false,
    "options": {}
  }))

  // remove
  collection.schema.removeField("bo3yeptu")

  // remove
  collection.schema.removeField("qr1cd2uy")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "g5s0zp6h",
    "name": "usuario",
    "type": "relation",
    "required": true,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "collectionId": "_pb_users_auth_",
      "cascadeDelete": false
    }
  }))

  return dao.saveCollection(collection)
})
