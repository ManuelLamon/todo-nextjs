migrate((db) => {
  const collection = new Collection({
    "id": "w5pjj2kr98teal2",
    "created": "2023-01-06 13:24:11.277Z",
    "updated": "2023-01-06 13:24:11.277Z",
    "name": "listas",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "mzi5luia",
        "name": "nombre",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "17j3jajf",
        "name": "tarea",
        "type": "relation",
        "required": false,
        "unique": false,
        "options": {
          "maxSelect": null,
          "collectionId": "vnqo14u55d0vubr",
          "cascadeDelete": false
        }
      },
      {
        "system": false,
        "id": "jqwg8xkq",
        "name": "proyecto",
        "type": "relation",
        "required": false,
        "unique": false,
        "options": {
          "maxSelect": 1,
          "collectionId": "ltpjrnlanenabg2",
          "cascadeDelete": false
        }
      }
    ],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("w5pjj2kr98teal2");

  return dao.deleteCollection(collection);
})
