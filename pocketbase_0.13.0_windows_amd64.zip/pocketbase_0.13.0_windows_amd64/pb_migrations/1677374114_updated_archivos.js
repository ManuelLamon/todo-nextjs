migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("zfny7t9q5gb37yj")

  collection.viewRule = "@request.auth.id != ''"

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("zfny7t9q5gb37yj")

  collection.viewRule = null

  return dao.saveCollection(collection)
})
