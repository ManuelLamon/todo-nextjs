migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("vnqo14u55d0vubr")

  // remove
  collection.schema.removeField("g0nijthg")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "nakp4u2h",
    "name": "fecha_fin",
    "type": "date",
    "required": false,
    "unique": false,
    "options": {
      "min": "",
      "max": ""
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("vnqo14u55d0vubr")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "g0nijthg",
    "name": "fecha_fin",
    "type": "text",
    "required": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  // remove
  collection.schema.removeField("nakp4u2h")

  return dao.saveCollection(collection)
})
