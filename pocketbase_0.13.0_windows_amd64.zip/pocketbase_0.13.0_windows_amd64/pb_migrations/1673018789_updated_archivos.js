migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("zfny7t9q5gb37yj")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "vxgd1ill",
    "name": "archivo",
    "type": "file",
    "required": true,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "maxSize": 5242880,
      "mimeTypes": [
        "application/zip",
        "application/x-7z-compressed",
        "application/x-rar-compressed"
      ],
      "thumbs": []
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("zfny7t9q5gb37yj")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "vxgd1ill",
    "name": "archivo",
    "type": "file",
    "required": true,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "maxSize": 5242880,
      "mimeTypes": [
        "application/zip",
        "application/x-7z-compressed",
        "application/x-rar-compressed/application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      ],
      "thumbs": []
    }
  }))

  return dao.saveCollection(collection)
})
