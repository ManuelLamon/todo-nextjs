migrate((db) => {
  const collection = new Collection({
    "id": "xg2ucpt190nbk8r",
    "created": "2023-01-06 13:17:00.616Z",
    "updated": "2023-01-06 13:17:00.616Z",
    "name": "usuarios_proyecto",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "hvs9amrz",
        "name": "proyecto",
        "type": "relation",
        "required": false,
        "unique": false,
        "options": {
          "maxSelect": 1,
          "collectionId": "ltpjrnlanenabg2",
          "cascadeDelete": false
        }
      },
      {
        "system": false,
        "id": "m1llzyth",
        "name": "usuarios",
        "type": "relation",
        "required": false,
        "unique": false,
        "options": {
          "maxSelect": 1,
          "collectionId": "_pb_users_auth_",
          "cascadeDelete": false
        }
      }
    ],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("xg2ucpt190nbk8r");

  return dao.deleteCollection(collection);
})
