migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("ltpjrnlanenabg2")

  // remove
  collection.schema.removeField("sdt1eljr")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "kwgwqfkj",
    "name": "estatus",
    "type": "relation",
    "required": true,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "collectionId": "bz1yy1pm46sc9p1",
      "cascadeDelete": false
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("ltpjrnlanenabg2")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "sdt1eljr",
    "name": "estatus",
    "type": "text",
    "required": true,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  // remove
  collection.schema.removeField("kwgwqfkj")

  return dao.saveCollection(collection)
})
