migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("w5pjj2kr98teal2")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "0dr9msnk",
    "name": "tipo",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "collectionId": "jc7j3t7vyhz2pco",
      "cascadeDelete": false,
      "minSelect": null,
      "maxSelect": 1,
      "displayFields": []
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("w5pjj2kr98teal2")

  // remove
  collection.schema.removeField("0dr9msnk")

  return dao.saveCollection(collection)
})
