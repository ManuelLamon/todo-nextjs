migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("vnqo14u55d0vubr")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "bo3yeptu",
    "name": "archivos",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "collectionId": "zfny7t9q5gb37yj",
      "cascadeDelete": false,
      "maxSelect": null,
      "displayFields": null
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("vnqo14u55d0vubr")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "bo3yeptu",
    "name": "archivos",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "collectionId": "zfny7t9q5gb37yj",
      "cascadeDelete": false,
      "maxSelect": 1,
      "displayFields": null
    }
  }))

  return dao.saveCollection(collection)
})
