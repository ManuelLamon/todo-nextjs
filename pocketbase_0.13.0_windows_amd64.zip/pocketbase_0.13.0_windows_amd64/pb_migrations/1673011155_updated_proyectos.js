migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("ltpjrnlanenabg2")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "6zvivogg",
    "name": "departamento",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "collectionId": "t6ml647y4no116f",
      "cascadeDelete": false
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("ltpjrnlanenabg2")

  // remove
  collection.schema.removeField("6zvivogg")

  return dao.saveCollection(collection)
})
