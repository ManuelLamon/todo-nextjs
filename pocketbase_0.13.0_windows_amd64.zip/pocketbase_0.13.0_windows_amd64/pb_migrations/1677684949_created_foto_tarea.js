migrate((db) => {
  const collection = new Collection({
    "id": "wdvz67s82yu8i2i",
    "created": "2023-03-01 15:35:49.251Z",
    "updated": "2023-03-01 15:35:49.251Z",
    "name": "foto_tarea",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "gokijtle",
        "name": "name",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "rr7vn0vl",
        "name": "url",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "erbijt65",
        "name": "tipo",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "lqwzhqju",
        "name": "tarea",
        "type": "relation",
        "required": false,
        "unique": false,
        "options": {
          "collectionId": "vnqo14u55d0vubr",
          "cascadeDelete": true,
          "minSelect": null,
          "maxSelect": 1,
          "displayFields": null
        }
      },
      {
        "system": false,
        "id": "gsmursnp",
        "name": "foto",
        "type": "file",
        "required": true,
        "unique": false,
        "options": {
          "maxSelect": 1,
          "maxSize": 5242880,
          "mimeTypes": [
            "image/jpeg",
            "image/png",
            "image/svg+xml",
            "image/gif",
            "image/webp"
          ],
          "thumbs": []
        }
      }
    ],
    "listRule": "@request.auth.id != ''",
    "viewRule": "@request.auth.id != ''",
    "createRule": "@request.auth.id != ''",
    "updateRule": "@request.auth.id != ''",
    "deleteRule": "@request.auth.id != ''",
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("wdvz67s82yu8i2i");

  return dao.deleteCollection(collection);
})
