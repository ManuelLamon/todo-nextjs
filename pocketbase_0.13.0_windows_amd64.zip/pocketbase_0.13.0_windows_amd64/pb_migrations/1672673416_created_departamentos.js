migrate((db) => {
  const collection = new Collection({
    "id": "t6ml647y4no116f",
    "created": "2023-01-02 15:30:16.873Z",
    "updated": "2023-01-02 15:30:16.873Z",
    "name": "departamentos",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "nldacvpx",
        "name": "nombre",
        "type": "text",
        "required": true,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      }
    ],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("t6ml647y4no116f");

  return dao.deleteCollection(collection);
})
