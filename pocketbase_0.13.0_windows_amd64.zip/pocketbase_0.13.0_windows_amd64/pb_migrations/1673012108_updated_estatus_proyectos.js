migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("bz1yy1pm46sc9p1")

  collection.name = "estatus"

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("bz1yy1pm46sc9p1")

  collection.name = "estatus_proyectos"

  return dao.saveCollection(collection)
})
