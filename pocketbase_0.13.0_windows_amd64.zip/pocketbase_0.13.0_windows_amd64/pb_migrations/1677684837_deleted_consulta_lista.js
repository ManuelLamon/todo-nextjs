migrate((db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("1i0w2ah8rofxs36");

  return dao.deleteCollection(collection);
}, (db) => {
  const collection = new Collection({
    "id": "1i0w2ah8rofxs36",
    "created": "2023-03-01 15:33:32.740Z",
    "updated": "2023-03-01 15:33:32.740Z",
    "name": "consulta_lista",
    "type": "view",
    "system": false,
    "schema": [],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {
      "query": "SELECT id FROM listas"
    }
  });

  return Dao(db).saveCollection(collection);
})
