migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("bz1yy1pm46sc9p1")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "dezf0rct",
    "name": "alias",
    "type": "text",
    "required": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("bz1yy1pm46sc9p1")

  // remove
  collection.schema.removeField("dezf0rct")

  return dao.saveCollection(collection)
})
