migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("w5pjj2kr98teal2")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "i8bihwj1",
    "name": "index",
    "type": "text",
    "required": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("w5pjj2kr98teal2")

  // remove
  collection.schema.removeField("i8bihwj1")

  return dao.saveCollection(collection)
})
